The samples are provided 'AS IS' by Microsoft and designed to assist
you in learning and understanding the power of ReadTrace, OSTRESS and ORCA.


The Samples directory is expected to reside under the installed RML 
binary files location.


Note: These samples are not intended for use on a production server.



Sample File/Dir		Description
---------------------	------------------------------------------------------------
Sample.ini		Sample control file that can be used with OSTRESS to control
			behavior.

\ReplayDeadlocks	Contains to examples showing you how to replay a set of RML
			files.   The first uses a single OSTRESS client and the second
			uses multiple clients.  If you want to learn how to perform
			a replay using OSTRESS this is a good sample.

\StressAQuery		Shows you how to use OSTRESS to execute a query 1000s of times
			from 100s of clients.    Also includes examples of how to do
			make/break connections.